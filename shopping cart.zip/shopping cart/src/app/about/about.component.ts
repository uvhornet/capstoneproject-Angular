import { Component } from '@angular/core';

@Component({
  templateUrl: './about.component.html'
  //styleUrls: ['./customer-detail.component.css']
})

export class AboutComponent { 
}
