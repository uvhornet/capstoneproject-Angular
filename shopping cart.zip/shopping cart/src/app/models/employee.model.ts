export interface Employee {
    id:number;
    name:string;
    description:string;
    manufacturer:string;
    price:number;
    quantity:number;
}
