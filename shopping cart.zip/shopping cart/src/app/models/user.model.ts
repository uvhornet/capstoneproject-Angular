export interface User{
    id:number;
    emailid:string;
    passwd:string;
    firstname: string;
    lastname: string;
    location: string;
    mobile: string;
}